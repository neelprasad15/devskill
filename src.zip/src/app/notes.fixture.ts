const Notes = [
    { id: 123, title: 'Testing note 1', body: 'Testing Note Body 1', color: '#ff0000', favourite: false },
    { id: 355, title: 'Testing note 2', body: 'Testing Note Body 2', color: '#00ff00', favourite: true },
    { id: 456, title: 'Testing note 3', body: 'Testing Note Body 3', color: '#0000ff', favourite: false },
];

export default Notes;
