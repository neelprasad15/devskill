export interface Note {
  id: number;
  title: string;
  body: string;
  color: string;
  favourite: boolean;
}
